from django.apps import AppConfig


class RestauctionportalConfig(AppConfig):
    name = 'RestAuctionPortal'
