from django.contrib import admin
from RestAuctionPortal.models import *

# Register your models here.

admin.site.register(SoldItemsData)
admin.site.register(Test)

